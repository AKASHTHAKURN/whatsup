class Exercise5_3
{ 
      public static void main(String[] args) 
      { 
		int[] arr = {10, 20, 30, 40, 50};
		int sum = 0;

		/*
		   (1) �˸��� �ڵ带 �־� �ϼ��Ͻÿ�.
		*/

		System.out.println("sum="+sum);
	}
}
