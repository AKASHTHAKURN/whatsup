class Exercise9_4 {
	static void printGraph(int[] dataArr, char ch) { 
		/*
			(1) printGraph�޼��带 �ۼ��Ͻÿ�.
		*/
	}

	public static void main(String[] args) {
		printGraph(new int[]{3,7,1,4},'*');
	}
}
