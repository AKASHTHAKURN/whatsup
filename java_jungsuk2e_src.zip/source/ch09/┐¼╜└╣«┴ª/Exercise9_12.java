class Exercise9_12
{
	/*
		(1) getRand�޼��带 �ۼ��Ͻÿ�.
	*/

	public static void main(String[] args) 
	{
		for(int i=0; i< 20; i++)
			System.out.print(getRand(1,-3)+",");
	}
}
