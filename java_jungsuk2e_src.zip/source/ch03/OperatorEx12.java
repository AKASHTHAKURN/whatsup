class OperatorEx12 
{ 
      public static void main(String[] args) 
      { 
            int a = 1000000 * 100000 / 1000000; 
            int b = 1000000 / 100000 * 1000000;
            System.out.println(a); 
            System.out.println(b); 
      } 
} 