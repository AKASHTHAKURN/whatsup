class  Exercise3_7 {
	public static void main(String[] args) {
		int fahrenheit = 100;
		float celcius = ( /* (1) */ );

		System.out.println("Fahrenheit:"+fahrenheit);
		System.out.println("Celcius:"+celcius);
	}
}
