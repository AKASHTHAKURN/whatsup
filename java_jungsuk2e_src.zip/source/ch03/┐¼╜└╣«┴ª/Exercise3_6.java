class  Exercise3_6 {
	public static void main(String[] args) {
		int num = 24;
		System.out.println( /* (1) */ );
	}
}
