class  Exercise3_9 {
	public static void main(String[] args) {
		char ch = 'z';
		boolean b = ( /* (1) */ );

		System.out.println(b);
	}
}
