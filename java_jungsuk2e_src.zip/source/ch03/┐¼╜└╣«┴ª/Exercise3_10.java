class  Exercise3_10 {
	public static void main(String[] args) {
		char ch = 'A';

		char lowerCase = ( /* (1) */ ) ? ( /* (2) */ ) : ch;

		System.out.println("upperCase:"+ch);
		System.out.println("lowerCase:"+lowerCase);
	}
}
