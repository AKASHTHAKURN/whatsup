class OperatorEx8 { 
      public static void main(String[] args) 
      { 
            byte a = 10; 
            byte b = 20; 
            byte c = a + b;  // byte c = (byte)(a+b);
            System.out.println(c); 
      } 
} 