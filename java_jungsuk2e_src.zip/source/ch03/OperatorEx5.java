class OperatorEx5 {
	public static void main(String[] args) 
	{
		byte b = 10;				
		System.out.println("b = " + b );
		System.out.println("~b = " + ~b);
		System.out.println("~b+1 = " + (~b+1));
	}
}