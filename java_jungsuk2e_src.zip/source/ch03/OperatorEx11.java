class OperatorEx11 
{ 
      public static void main(String[] args) 
      { 
            long a = 1000000 * 1000000;
            long b = 1000000 * 1000000L;  // long�� ���ͷ�
            System.out.println(a); 
            System.out.println(b); 
      } 
}