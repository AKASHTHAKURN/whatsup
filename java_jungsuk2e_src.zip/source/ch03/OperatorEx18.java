class OperatorEx18
{ 
      public static void main(String[] args) 
      { 
                  float pi = 3.141592f; 
                  float shortPi = Math.round(pi * 1000) / 1000f; 

                  System.out.println(shortPi); 
      } 
} 