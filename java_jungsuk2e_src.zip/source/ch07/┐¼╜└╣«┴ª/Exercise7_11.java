class MyTv2 {
	/*
		(1) ����7-10�� MyTv2Ŭ������ gotoPrevChannel�޼��带 �߰��Ͽ� �ϼ��Ͻÿ�.
	*/
}

class Exercise7_11 {
	public static void main(String args[]) {
		MyTv2 t = new MyTv2();

		t.setChannel(10);
		System.out.println("CH:"+t.getChannel());
		t.setChannel(20);
		System.out.println("CH:"+t.getChannel());
		t.gotoPrevChannel();
		System.out.println("CH:"+t.getChannel());
		t.gotoPrevChannel();
		System.out.println("CH:"+t.getChannel());
	}
}
