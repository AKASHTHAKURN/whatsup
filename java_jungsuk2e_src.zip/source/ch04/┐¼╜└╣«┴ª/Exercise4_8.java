class  Exercise4_8 {
	public static void main(String[] args) {
		String str = "12345";
		int sum = 0;

		for(int i=0; i < str.length(); i++) {
			/*
				 (1) �˸��� �ڵ带 �־� �ϼ��Ͻÿ�.
			*/
		}

		System.out.println("sum="+sum);
	}
}
