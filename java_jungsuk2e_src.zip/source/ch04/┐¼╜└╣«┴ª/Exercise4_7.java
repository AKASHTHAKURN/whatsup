class  Exercise4_7 {
	public static void main(String[] args) {
		int value = ( /* (1) */ );

		System.out.println("value:"+value);
	}
}
