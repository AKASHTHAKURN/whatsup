import java.util.*;

class Exercise11_19 {
	/*
	   (1) getDayDiff�޼��带 �ۼ��Ͻÿ�.
	*/


	public static void main(String[] args){
		System.out.println(getDayDiff("20010103","20010101"));
		System.out.println(getDayDiff("20010103","20010103"));
		System.out.println(getDayDiff("20010103","200103"));
	}
}
